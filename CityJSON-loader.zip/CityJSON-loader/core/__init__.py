"""A module that provide classes in order to manage data from CityJSON
to QGIS layers and features
"""
