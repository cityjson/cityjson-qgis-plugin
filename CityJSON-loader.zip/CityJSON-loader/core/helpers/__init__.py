"""A module that provide helper functions
"""
